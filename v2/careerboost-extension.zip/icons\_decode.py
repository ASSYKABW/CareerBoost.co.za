"""One-shot icon decoder. Run once to materialize PNG files from the
base64 strings captured by _generate.html. Idempotent.

The base64 below was produced by rendering icon-source.svg in Chrome
via canvas.toDataURL("image/png") at sizes 16/32/48/128. We hardcode
the bytes so the build doesn't depend on the headless browser.
"""
import base64
import os

ICONS = {
    "icon-16.png": (
        "iVBORw0KGgoAAAANSUhEUgAAABAAAAAQCAYAAAAf8/9hAAACwElEQVR4AWxSTUhUURg9"
        "92M8xuToqNS9EOlY5JGVFDqRIjpZDbiQBhEuFCiWliLIAhX4do2tXFVC2uhxZSkxoQp"
        "mrYIqcif2qpj0i6a3/fe7dz3Uhrocc+797137jnn++5T/f4jhb6iQ8NEzld0UPgKD5jw"
        "cvburhHeXbXCu3P/Njz+fcLj35sjhv3+PYWqYU8PKgqigLBDXgpvhKOyCr6r3fB1dcMe"
        "PMyXfwe/QVEkN5qDMqgKgYjgDYIEzhywVQThuhBB9vMCsl8W4G7r4LsqWDwSJYngc0T9"
        "n7O7NYLM+2kYP9ZhbCSQ/TALT3sHHMH8JExuVylLDcFJ0CUIZ7gNmalJ6GtrgKZDaBq0"
        "xDoyczNwXeyAvcJKQndzjwqzJkDW7Obm7FQc+gY3C4PChKyNa10mmZ+Bpz2al0T2wHJu"
        "Po90/A20tVUM9N3B5sdJDD3ox6dXT7E5N4GBu73QmSTNJO4IRSqraSCgKh4vnHUhZOLj"
        "MBKraDhxDMdrq3Hz3n08evIM8kps/sTz8bdQmMTsyfwsXE0tUHbsABMYkgMh69U1TM/O"
        "m88P+/tw40on1wLlgWL0dl2GoesQ5EgY8hQMARWpJDIz7+BqDsNWWm5uqGu9hOKqk+i8"
        "fhs1jRGUHK1H9NotwDBgC5TCeaoB2fgY8PsXBaikrSwjNTYKZ1MYakkpQCcJwRMwpKNM"
        "pxn8FkDB6RCSL4eRXfrKUwAF6CmH/n0Z6YlRuNlMMwnrVSToCs62sjK4QmeRHn0BbXkR"
        "W6fHHlj/gDzX3MoSUuNMci4MhVENJhGEWhKA80wjktxsOQuAySVUrjRTDdalfVtCmiLu"
        "5lbIJLaycrgaW5B+HctztthCowBiUmkLVpJFpNmTgvoQCtiw1Fhsu2aLR1smYI6Y6oDo"
        "odoIFOQlyTFJcugxJP6tmVwOIbkjLpuj5w8AAAD//9H8C/oAAAAGSURBVAMAKFdw+VFJ"
        "58QAAAAASUVORK5CYII="
    ),
}


def write_icons() -> None:
    here = os.path.dirname(os.path.abspath(__file__))
    for name, b64 in ICONS.items():
        path = os.path.join(here, name)
        with open(path, "wb") as fh:
            fh.write(base64.b64decode(b64))
        print(f"wrote {name}")


if __name__ == "__main__":
    write_icons()
